package com.jingyan.agri;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("sub2")
public class Controller1 {

	@RequestMapping("")
	String home() {
		return "sub.jsp";
	}
}
